﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pastabar.Models;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace Pastabar.Services
{
    public class NieuwsBriefService
    {
        private Dictionary<int, NieuwsBrief> nieuwsBrief = new Dictionary<int, NieuwsBrief>();
        public void Add(NieuwsBrief nb)
        {
            if (nieuwsBrief.Count != 0)
            {
                nb.ID = nieuwsBrief.Keys.Max() + 1;

            }
            else
            {
                nb.ID = 1;
            }
            nieuwsBrief.Add(nb.ID, nb);
        }
    }
}
