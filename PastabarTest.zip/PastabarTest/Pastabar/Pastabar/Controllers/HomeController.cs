﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Pastabar.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;


namespace Pastabar.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult bestellenData(Bestellen bestellen)
        {

            List<Bestellen> bestellenLijst = new List<Bestellen>();
            var bestellingen = HttpContext.Session.GetString("bestellingen");
            if (!string.IsNullOrEmpty(bestellingen))
            {
                bestellenLijst = JsonConvert.DeserializeObject<List<Bestellen>>(bestellingen);
            }
            bestellenLijst.Add(bestellen);
            var geserializeerdeBestellingLijst = JsonConvert.SerializeObject(bestellenLijst);
            HttpContext.Session.SetString("bestellingen", geserializeerdeBestellingLijst);
            return RedirectToAction("Index");

        }



        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
