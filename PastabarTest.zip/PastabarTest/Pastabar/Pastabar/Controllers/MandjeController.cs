﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Pastabar.Models;

namespace Pastabar.Controllers
{
    public class MandjeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            List<Bestellen> bestellenLijst = new List<Bestellen>();
            var bestellingen = HttpContext.Session.GetString("bestellingen");
            if (!string.IsNullOrEmpty(bestellingen))
            {
                bestellenLijst = JsonConvert.DeserializeObject<List<Bestellen>>(bestellingen);
            }
            return View(bestellenLijst);

        }

        public IActionResult doorSturen()
        {
            if (HttpContext.Session.GetString("bestellingen") != null)
                HttpContext.Session.Remove("bestellingen");
            return View();
        }
    }
}
