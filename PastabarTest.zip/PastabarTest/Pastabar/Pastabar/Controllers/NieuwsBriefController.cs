﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Globalization;
using Pastabar.Models;
using Pastabar.Services;

namespace Pastabar.Controllers
{
    public class NieuwsBriefController : Controller
    {
        private NieuwsBriefService _nieuwsBriefService;
        public NieuwsBriefController(NieuwsBriefService nieuwsBriefService)
        {
            _nieuwsBriefService = nieuwsBriefService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Inschrijven(NieuwsBrief nieuwsBrief)
        {
            if (this.ModelState.IsValid)
            {
                _nieuwsBriefService.Add(nieuwsBrief);

                return View(nieuwsBrief);
            }
            else
                return RedirectToAction("Index");


        }
        public IActionResult ValideerGeboortedatum(string Geboortedatum)
        {
            DateTime doorgegevenDatum;
            var nlDate = DateTime.TryParseExact(Geboortedatum, "dd/MM/yyyy",
                                                CultureInfo.GetCultureInfo("nl-BE"), DateTimeStyles.None,
                                                out doorgegevenDatum);           
            var ukDate = DateTime.TryParseExact(Geboortedatum, "yyyy-MM-dd",
                                                CultureInfo.GetCultureInfo("en-US"), DateTimeStyles.None,
                                                out doorgegevenDatum);                     
            if (!nlDate && !ukDate)
            {
                return Json("Gelieve een geldige datum in te voeren (dd/mm/jjjj) !");
            }            
            else if (DateTime.Now < doorgegevenDatum)
            {
                return Json("Voer een datum uit het verleden in !");
            }
            else
            {
                return Json(true);
            }
        }
    }
}
