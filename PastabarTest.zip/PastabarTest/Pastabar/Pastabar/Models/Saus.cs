﻿public enum Saus
{
    Bolognaise, Veggie, Curry, Arrabiata, Pesto
}