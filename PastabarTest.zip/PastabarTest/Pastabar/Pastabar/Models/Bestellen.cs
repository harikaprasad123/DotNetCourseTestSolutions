﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using Microsoft.AspNetCore.Mvc;

namespace Pastabar.Models
{
    public class Bestellen
    {
        //public int ID { get; set; }
        public Pasta Pasta { get; set; }

        public Grootte Grootte { get; set; }

        public Saus Saus { get; set; }
    }
}
