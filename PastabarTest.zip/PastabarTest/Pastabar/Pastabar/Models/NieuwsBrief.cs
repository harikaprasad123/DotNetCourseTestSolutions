﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using Microsoft.AspNetCore.Mvc;


namespace Pastabar.Models
{
    public class NieuwsBrief
    {
        public int ID { get; set; }


        [Required(ErrorMessage = "Naam is verplicht")]
        public string Naam { get; set; }

        [Required(ErrorMessage = "Voor Naam is verplicht")]
        public string Voornaam { get; set; }

        [RegularExpression(@"[^\s]+@[^\s.]+\.[a-z]+", ErrorMessage = "Email verkeerd")]
        [Required(ErrorMessage = "Email is verplicht")]
        public string Emailadres { get; set; }

        [Required(ErrorMessage = "Telefoon Nummer is verplicht")]
        public string Telefoonnummer { get; set; }

        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        [Remote("ValideerGeboortedatum", "NieuwsBrief")]
        [Required(ErrorMessage = "Geboorte Datum is verplicht")]
        public DateTime Geboortedatum { get; set; }


    }
}
