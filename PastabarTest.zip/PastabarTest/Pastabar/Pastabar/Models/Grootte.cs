﻿public enum Grootte
{
    Small, Regular, Big
}