﻿public enum Pasta
{
    Penne, Spaghetti, Fusilli
}