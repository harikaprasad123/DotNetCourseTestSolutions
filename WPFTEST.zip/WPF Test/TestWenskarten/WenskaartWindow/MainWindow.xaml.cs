﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WenskaartWindow
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        private int grotte;
        public int ellipseCount;
        Ellipse ellipsebal;
        Canvas CanvasEllipseBal;
        string achtergrond;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (PropertyInfo info in typeof(Colors).GetProperties())
            {
                Kleuren.Items.Add(info.Name);

            }

        }
        private void Window_Closing(object sender, CancelEventArgs e)
        {
            if (MessageBox.Show("Programma afsluiten ?",
                                "Afsluiten",
                                MessageBoxButton.YesNo,
                                MessageBoxImage.Question,
                                MessageBoxResult.No) == MessageBoxResult.No)
                e.Cancel = true;
        }
        private void NewExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            TextWens.Text = "";
            Grotte.Content = "10";
            WensBal.Fill = null;
            Kleuren.SelectedIndex = 0;
            LettertypeComboBox.SelectedIndex = 0;
            WensCanvas.Background = null;
            ellipseCount = 0;
            WensCanvas.Children.Clear();
            StatusKaartPath.Content = "Nieuwe";
            SaveFile.IsEnabled = true;

        }
        private void OpenExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.FileName = "";
                dlg.DefaultExt = ".wk";
                dlg.Filter = "Wenskaarten |*.wk";
                if (dlg.ShowDialog() == true)
                {
                    using (StreamReader bestand = new StreamReader(dlg.FileName))
                    {
                        int antalballen = int.Parse(bestand.ReadLine());
                        for (int i = 0; i < antalballen; i++)
                        {
                            Ellipse ellipse = new Ellipse
                            {
                                Fill = (SolidColorBrush)new BrushConverter().ConvertFromString(bestand.ReadLine())
                            };
                            double x = double.Parse(bestand.ReadLine());
                            double y = double.Parse(bestand.ReadLine());
                            Canvas.SetLeft(ellipse, x); 
                            Canvas.SetTop(ellipse, y); 
                            WensCanvas.Children.Add(ellipse); 
                        }
                        achtergrond = bestand.ReadLine();
                        ImageBrush imgBrush = new ImageBrush();
                        imgBrush.ImageSource = new BitmapImage(new Uri(achtergrond, UriKind.Absolute));
                        WensCanvas.Background = imgBrush;



                        LettertypeComboBox.SelectedValue = new FontFamily(bestand.ReadLine());
                        TypeConverter convertFamily = TypeDescriptor.GetConverter(typeof(FontFamily));
                        TextWens.FontFamily = (FontFamily)convertFamily.ConvertFromString(bestand.ReadLine());
                        TextWens.FontSize = int.Parse(bestand.ReadLine());
                        TextWens.Text = bestand.ReadLine();
                    }
                }
                SaveFile.IsEnabled = true;
                StatusKaartPath.Content = dlg.FileName.ToString();
            }
            catch (Exception ex) { MessageBox.Show("openen mislukt : " + ex.Message); }

        }


        private void SaveExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                SaveFileDialog dlg = new SaveFileDialog();
                dlg.FileName = "Wenskaart.wk";
                dlg.DefaultExt = ".wk";
                dlg.Filter = "Wenskaarten |*.wk";
                if (dlg.ShowDialog() == true)
                {
                    using (StreamWriter bestand = new StreamWriter(dlg.FileName))
                    {
                        bestand.WriteLine(WensCanvas.Children.Count);
                        foreach (Ellipse bal in WensCanvas.Children)
                        {
                            var x = Canvas.GetLeft(bal);
                            var y = Canvas.GetTop(bal);                          
                            bestand.WriteLine(bal.Fill);
                            bestand.WriteLine(x.ToString());
                            bestand.WriteLine(y.ToString());
                        }

                        bestand.WriteLine(achtergrond);
                        bestand.WriteLine(LettertypeComboBox.SelectedValue);
                        bestand.WriteLine(TextWens.FontFamily.ToString());
                        bestand.WriteLine(TextWens.FontSize.ToString());
                        bestand.WriteLine(TextWens.Text);
                        bestand.WriteLine(Grotte.Content.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("opslaan mislukt:" + ex.Message);
            }
        }
        private void CloseExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            this.Close();
        }

        private void Kerstkaart_Click(object sender, RoutedEventArgs e)
        {

            achtergrond = "pack://application:,,,/Images/kerstkaart.jpg";

            ImageBrush imgBrush = new ImageBrush();
            imgBrush.ImageSource = new BitmapImage(new Uri(achtergrond, UriKind.Absolute));
            WensCanvas.Background = imgBrush;
            SaveFile.IsEnabled = true;

        }

        private void Geboortekaart_Click(object sender, RoutedEventArgs e)
        {

            achtergrond = "pack://application:,,,/Images/geboortekaart.jpg";
            ImageBrush imgBrush = new ImageBrush();
            imgBrush.ImageSource = new BitmapImage(new Uri(achtergrond, UriKind.Absolute));
            WensCanvas.Background = imgBrush;
            SaveFile.IsEnabled = true;
        }

        private void Kleuren_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            WensBal.Fill = (SolidColorBrush)new BrushConverter().ConvertFromString(Kleuren.SelectedItem.ToString());

        }

        private void LettertypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TextWens.FontFamily = (FontFamily)LettertypeComboBox.SelectedItem;
        }

        private void TextSizeVerhogen(object sender, RoutedEventArgs e)
        {

            grotte = Convert.ToInt32(Grotte.Content);
            if (grotte < 30)
                grotte++;
            Grotte.Content = grotte.ToString();
            TextWens.FontSize = grotte;

        }

        private void TextSizeVerminderen(object sender, RoutedEventArgs e)
        {
            grotte = Convert.ToInt32(Grotte.Content);
            if (grotte > 1)
                grotte--;
            Grotte.Content = grotte.ToString();
            TextWens.FontSize = grotte;
        }

        private void DragEllipse_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                ellipsebal = (Ellipse)sender;
                Ellipse gesleepteBal = (Ellipse)e.OriginalSource;

                DataObject sleepdata = new DataObject("deBal", gesleepteBal);
                DragDrop.DoDragDrop(gesleepteBal, sleepdata, DragDropEffects.Move);

            }
        }

        private void DropEllipse_Drop(object sender, DragEventArgs e)
        {

            if (e.Data.GetDataPresent("deBal"))
            {
                Ellipse gesleepteBal = (Ellipse)e.Data.GetData("deBal");
                Ellipse newEllipseBal = new Ellipse
                {
                    Fill = gesleepteBal.Fill
                };
                var Position = e.GetPosition(WensCanvas);
                Canvas.SetLeft(newEllipseBal, Position.X - 20); 
                Canvas.SetTop(newEllipseBal, Position.Y - 20); 


                WensCanvas.Children.Add(newEllipseBal); 
                ellipseCount++;

            }
        }

        private void CanvasEllipseBal_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                CanvasEllipseBal = (Canvas)sender;
                Ellipse gesleepteCanvasEllipseBal = (Ellipse)e.OriginalSource;

                DataObject sleepdata = new DataObject("deCanvasEllipseBal", gesleepteCanvasEllipseBal);
                DragDrop.DoDragDrop(gesleepteCanvasEllipseBal, sleepdata, DragDropEffects.Move);

            }
        }

        private void DropCanvasEllipseBall_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("deCanvasEllipseBal"))
            {
                Ellipse gesleepteBal = (Ellipse)e.Data.GetData("deCanvasEllipseBal");               

                WensCanvas.Children.Remove(gesleepteBal);
                ellipseCount--;

            }
        }
    }
}
