﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Wenskarten.Model
{
    public class Wenskaart
    {
        public Wenskaart()
        {
            Achtergrond = null;
            Ballen = new ObservableCollection<Bal>();
            TextWens = string.Empty;
            WensLettertype = string.Empty;
            WensLettergrootte = 10;
        }

        public ImageBrush Achtergrond { get; set; }
        public int AantalBallen
        {
            get
            {
                return Ballen.Count;
            }
        }
        public ObservableCollection<Bal> Ballen { get; set; }
        public string TextWens { get; set; }
        public string WensLettertype { get; set; }
        public int WensLettergrootte { get; set; }
    }
}
